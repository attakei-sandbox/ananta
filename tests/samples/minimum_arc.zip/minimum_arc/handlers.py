# -*- coding:utf8 -*-
"""
"""
from ananta import lambda_config


@lambda_config
def test_funcs(event, context):
    return {}
